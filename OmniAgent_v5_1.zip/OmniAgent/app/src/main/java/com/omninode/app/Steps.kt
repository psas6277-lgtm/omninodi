package com.omninode.app

import android.accessibilityservice.AccessibilityService
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Settings
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject

/** Поиск и запуск приложений по названию. */
object Apps {
    private val alias = mapOf(
        "телеграм" to "telegram", "телега" to "telegram", "тг" to "telegram",
        "ютуб" to "youtube", "ютьюб" to "youtube",
        "вк" to "vk", "вконтакте" to "vk",
        "ватсап" to "whatsapp", "вотсап" to "whatsapp",
        "инстаграм" to "instagram", "тикток" to "tiktok",
        "хром" to "chrome", "карты" to "карты", "почта" to "gmail", "гмейл" to "gmail",
        "сбер" to "сбер", "тинькофф" to "тинькофф", "т-банк" to "т-банк",
        "настройки" to "settings", "камера" to "camera", "галерея" to "gallery"
    )

    fun find(c: Context, name: String): String? {
        val pm = c.packageManager
        var q = name.lowercase().trim()
        if (q.isEmpty()) return null
        q = alias[q] ?: q
        val apps = try { pm.getInstalledApplications(0) } catch (e: Exception) { return null }
        val launchable = apps.filter { pm.getLaunchIntentForPackage(it.packageName) != null }
        fun lab(a: android.content.pm.ApplicationInfo) = pm.getApplicationLabel(a).toString().lowercase()
        val hit = launchable.firstOrNull { lab(it) == q }
            ?: launchable.firstOrNull { lab(it).startsWith(q) }
            ?: launchable.firstOrNull { lab(it).contains(q) }
            ?: launchable.firstOrNull { it.packageName.lowercase().contains(q.replace(" ", "")) }
        return hit?.packageName
    }

    fun open(c: Context, name: String): Boolean {
        val p = find(c, name) ?: return false
        return openPkg(c, p)
    }

    fun openPkg(c: Context, pkg: String): Boolean {
        val i = c.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        OverlayService.inst?.coreCollapse()
        return try { c.startActivity(i); true } catch (e: Exception) { false }
    }

    fun label(c: Context, pkg: String): String = try {
        c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    /** Открыть ссылку или intent:-URI (с очисткой опасных полей). */
    fun openUri(c: Context, u: String): Boolean {
        return try {
            var fallback: String? = null
            val i = if (u.startsWith("intent:")) {
                val x = Intent.parseUri(u, Intent.URI_INTENT_SCHEME)
                fallback = x.getStringExtra("browser_fallback_url")
                x.component = null
                x.selector = null
                x
            } else Intent(Intent.ACTION_VIEW, Uri.parse(u))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { c.startActivity(i); true } catch (e: Exception) {
                if (fallback != null) {
                    val f = Intent(Intent.ACTION_VIEW, Uri.parse(fallback)); f.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    c.startActivity(f); true
                } else false
            }
        } catch (e: Exception) { false }
    }
}

/** Контакты телефона. */
object Contacts {
    fun number(c: Context, name: String): String? {
        if (name.isBlank()) return null
        return try {
            val cur = c.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                arrayOf("%" + name.trim() + "%"),
                null
            )
            cur?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Exception) { null }
    }
}

/** Системные действия: громкость, яркость, фонарик, режимы, медиа. */
object Sys {
    fun audio(c: Context) = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun stream(k: String): Int = when (k) {
        "r" -> AudioManager.STREAM_RING
        "n" -> AudioManager.STREAM_NOTIFICATION
        "a" -> AudioManager.STREAM_ALARM
        else -> AudioManager.STREAM_MUSIC
    }

    fun setVolume(c: Context, k: String, pct: Int): Boolean {
        return try {
            val a = audio(c); val s = stream(k)
            val mx = a.getStreamMaxVolume(s)
            a.setStreamVolume(s, (mx * pct.coerceIn(0, 100) / 100f).toInt(), AudioManager.FLAG_SHOW_UI)
            true
        } catch (e: Exception) { false }
    }

    fun mute(c: Context): Boolean = try {
        audio(c).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); true
    } catch (e: Exception) { false }

    fun torch(c: Context, on: Boolean): Boolean = try {
        val m = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        m.setTorchMode(m.cameraIdList[0], on); true
    } catch (e: Exception) { false }

    fun brightness(c: Context, pct: Int): Boolean {
        if (!Settings.System.canWrite(c)) {
            try {
                val i = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + c.packageName)); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                c.startActivity(i)
            } catch (e: Exception) {}
            return false
        }
        return try {
            Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (255 * pct.coerceIn(1, 100) / 100f).toInt())
            true
        } catch (e: Exception) { false }
    }

    fun currentBrightnessPct(c: Context): Int = try {
        Settings.System.getInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS) * 100 / 255
    } catch (e: Exception) { 50 }

    fun dnd(c: Context, on: Boolean): Boolean {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            try { val i = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i) } catch (e: Exception) {}
            return false
        }
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL)
        return true
    }

    fun silent(c: Context, on: Boolean): Boolean {
        val a = audio(c)
        return try {
            a.ringerMode = if (on) AudioManager.RINGER_MODE_SILENT else AudioManager.RINGER_MODE_NORMAL; true
        } catch (e: Exception) {
            try { a.ringerMode = if (on) AudioManager.RINGER_MODE_VIBRATE else AudioManager.RINGER_MODE_NORMAL; true } catch (x: Exception) { false }
        }
    }

    fun rotate(c: Context, on: Boolean): Boolean {
        if (!Settings.System.canWrite(c)) return false
        return try { Settings.System.putInt(c.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (on) 1 else 0); true } catch (e: Exception) { false }
    }

    private fun controller(c: Context): MediaController? {
        return try {
            val m = c.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list: List<MediaController> = m.getActiveSessions(ComponentName(c, OmniNotifService::class.java))
            list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
        } catch (e: Exception) { null }
    }

    fun media(c: Context, op: String): Boolean {
        val ctl = controller(c)
        if (ctl != null) {
            val t = ctl.transportControls
            when {
                op == "play" -> t.play()
                op == "pause" -> t.pause()
                op == "next" -> t.skipToNext()
                op == "prev" -> t.skipToPrevious()
                op.startsWith("seek:") -> t.seekTo((op.substring(5).toLongOrNull() ?: 0L) * 1000L)
                else -> return false
            }
            return true
        }
        val code = when (op) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return false
        }
        return try {
            val a = audio(c)
            a.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            a.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code)); true
        } catch (e: Exception) { false }
    }

    fun nav(c: Context, k: String): String {
        val s = AgentService.inst ?: return "нужен доступ к экрану"
        return when (k) {
            "lock" -> if (Build.VERSION.SDK_INT >= 28) { s.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN); "экран заблокирован" } else "нужен Android 9+"
            "shot" -> if (Build.VERSION.SDK_INT >= 28) { s.global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT); "скриншот сделан" } else "нужен Android 9+"
            "back" -> { s.global(AccessibilityService.GLOBAL_ACTION_BACK); "назад" }
            "home" -> { s.global(AccessibilityService.GLOBAL_ACTION_HOME); "домой" }
            "recents" -> { s.global(AccessibilityService.GLOBAL_ACTION_RECENTS); "последние приложения" }
            "down" -> { s.scroll(true); "прокрутила вниз" }
            "up" -> { s.scroll(false); "прокрутила вверх" }
            "notif" -> { s.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); "шторка открыта" }
            else -> "неизвестное действие"
        }
    }

    fun powerOff(c: Context): Boolean {
        val s = AgentService.inst ?: return false
        s.global(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)
        Handler(Looper.getMainLooper()).postDelayed({
            Thread {
                val a = AgentService.inst
                if (a != null) { a.tapText("Выключить") || a.tapText("Power off") || a.tapText("Выключение") }
            }.start()
        }, 1200)
        return true
    }

    val TILES = mapOf(
        "wifi" to listOf("wi-fi", "wifi", "интернет", "internet"),
        "bt" to listOf("bluetooth", "блютуз"),
        "data" to listOf("мобильн", "mobile data", "передача данных", "данные"),
        "air" to listOf("режим полёта", "режим полета", "airplane", "авиа"),
        "gps" to listOf("геолокац", "location", "местополож"),
        "hot" to listOf("точка доступа", "hotspot", "модем"),
        "dark" to listOf("тёмная", "темная", "темная тема", "dark"),
        "rotate" to listOf("автоповорот", "auto-rotate", "auto rotate", "поворот")
    )

    /** Переключатели телефона. v — значение для яркости (0..100, либо ±20 как «чуть ярче/темнее»). */
    fun tog(c: Context, k: String, on: Boolean?, v: Int?): String {
        when (k) {
            "torch" -> return if (torch(c, on != false)) "фонарик " + (if (on != false) "включён" else "выключен") else "не удалось"
            "silent" -> return if (silent(c, on != false)) "беззвучный режим переключён" else "нужен доступ к «Не беспокоить»"
            "bright" -> {
                val cur = currentBrightnessPct(c)
                val t = if (v == null) 100 else if (v == 20 || v == -20) (cur + v).coerceIn(1, 100) else v
                return if (brightness(c, t)) "яркость $t%" else "разреши «Изменение системных настроек» и повтори"
            }
            "rotate" -> if (rotate(c, on != false)) return "автоповорот переключён"
        }
        val names = TILES[k] ?: return "неизвестный переключатель"
        val s = AgentService.inst ?: return "нужен доступ к экрану"
        return s.toggleTile(names, on)
    }
}

/** Исполнитель шагов старого JS-протокола и действий по расписанию. */
object Steps {
    private fun toast(c: Context, t: String) { try { OverlayService.inst?.setIsland(t.take(60)) } catch (e: Exception) {} }

    fun runStep(c: Context, s: JSONObject) {
        try {
            if (s.has("u")) {
                val u = s.optString("u")
                if (!Apps.openUri(c, u)) toast(c, "Не удалось открыть")
                return
            }
            if (s.has("app")) {
                val a = s.optJSONObject("app")
                val pkg = a?.optString("pkg") ?: ""
                val n = a?.optString("n") ?: ""
                val fb = a?.optString("fb") ?: ""
                val ok = (pkg.isNotBlank() && Apps.openPkg(c, pkg)) || (n.isNotBlank() && Apps.open(c, n))
                if (!ok) {
                    if (fb.isNotBlank()) Apps.openUri(c, fb)
                    else if (n.isNotBlank()) Apps.openUri(c, "market://search?q=" + Uri.encode(n))
                }
                return
            }
            if (s.has("close")) { AgentService.inst?.global(AccessibilityService.GLOBAL_ACTION_HOME); return }
            if (s.has("dnd")) { Sys.dnd(c, s.optInt("dnd") == 1); return }
            if (s.has("media")) { Sys.media(c, s.optString("media")); return }
            if (s.has("vol")) {
                val v = s.optJSONObject("vol")
                if (v != null && v.has("v")) Sys.setVolume(c, "m", v.optInt("v"))
                else {
                    val up = v?.optString("op") == "up"
                    Sys.audio(c).adjustStreamVolume(AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                }
                return
            }
            if (s.has("tog")) {
                val t = s.optJSONObject("tog") ?: return
                val on: Boolean? = if (t.has("on")) t.optBoolean("on") else null
                val v: Int? = if (t.has("v")) t.optInt("v") else null
                toast(c, Sys.tog(c, t.optString("k"), on, v))
                return
            }
            if (s.has("nav")) { toast(c, Sys.nav(c, s.optJSONObject("nav")?.optString("k") ?: "")); return }
            if (s.has("callc")) { call(c, s.optJSONObject("callc")?.optString("name") ?: ""); return }
            if (s.has("msg")) {
                val m = s.optJSONObject("msg") ?: return
                message(c, m.optString("to"), m.optString("text"), m.optString("via"))
                return
            }
            if (s.has("chat")) {
                val n = s.optJSONObject("chat")?.optString("name") ?: ""
                NativeAgent.start(c, "Открой переписку с контактом «$n» (в мессенджере, где она есть) и остановись, когда она открыта.", null)
                return
            }
        } catch (e: Exception) { toast(c, "Ошибка шага") }
    }

    /** Цепочка шагов: выполняется по очереди в фоне, чтобы не зависеть от WebView. */
    fun runChain(c: Context, arr: JSONArray) {
        Thread {
            for (i in 0 until arr.length()) {
                val s = arr.optJSONObject(i) ?: continue
                runStep(c, s)
                val heavy = s.has("app") || s.has("close") || s.has("tog") || s.has("u")
                try { Thread.sleep(if (heavy) 2000 else 700) } catch (e: Exception) {}
            }
        }.start()
    }

    fun call(c: Context, name: String) {
        val num = if (name.matches(Regex("[+\\d][\\d\\s\\-()]{4,}"))) name else Contacts.number(c, name)
        if (num == null) { toast(c, "Контакт «$name» не найден"); return }
        val tel = Uri.parse("tel:" + Uri.encode(num))
        try {
            val i = Intent(Intent.ACTION_CALL, tel); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i)
        } catch (e: Exception) {
            try { val i = Intent(Intent.ACTION_DIAL, tel); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i) } catch (x: Exception) {}
        }
    }

    fun message(c: Context, to: String, text: String, via: String) {
        val num = Contacts.number(c, to)
        if ((via == "sms" || via.isBlank()) && num != null) {
            Thread {
                try {
                    val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num)))
                    i.putExtra("sms_body", text); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    c.startActivity(i)
                    Thread.sleep(2200)
                    val a = AgentService.inst
                    if (a != null) { a.tapText("Отправить") || a.tapText("Send") }
                } catch (e: Exception) { toast(c, "SMS не отправлено") }
            }.start()
            return
        }
        val app = when (via) { "wa" -> "WhatsApp"; "mail" -> "почту (Gmail)"; "sms" -> "сообщения (SMS)"; else -> "Telegram" }
        NativeAgent.start(c, "Открой $app, найди контакт «$to» и отправь ему сообщение: «$text». После отправки — готово.", null)
    }

    /** Действие из расписания (в «высоком» формате: t = app/tog/msg/callc/nav/volume). */
    fun runAction(c: Context, a: JSONObject) {
        val step = JSONObject()
        when (a.optString("t")) {
            "app" -> step.put("app", JSONObject().put("n", a.optString("n")))
            "tog" -> step.put("tog", JSONObject().put("k", a.optString("k")).put("on", a.optBoolean("on", true)).also { if (a.has("v")) it.put("v", a.optInt("v")) })
            "msg" -> step.put("msg", JSONObject().put("to", a.optString("to")).put("text", a.optString("text")).put("via", a.optString("via")))
            "callc" -> step.put("callc", JSONObject().put("name", a.optString("name")))
            "nav" -> step.put("nav", JSONObject().put("k", a.optString("k")))
            "volume" -> step.put("vol", JSONObject().put("v", a.optInt("v")))
            else -> return
        }
        runStep(c, step)
    }
}
