package com.omninode.app

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Озвучка через системный Android TextToSpeech. */
object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private val pending = ArrayList<Array<String>>()
    private var lastText = ""
    private var lastAt = 0L

    /** Вызывается, когда фраза с данным id дочитана (или не удалось прочитать). */
    var onDone: ((String) -> Unit)? = null

    fun init(c: Context) {
        if (tts != null) return
        val ctx = c.applicationContext
        tts = TextToSpeech(ctx) { st ->
            ready = (st == TextToSpeech.SUCCESS)
            val e = tts
            if (ready && e != null) {
                e.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { if (utteranceId != null) onDone?.invoke(utteranceId) }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { if (utteranceId != null) onDone?.invoke(utteranceId) }
                })
                val copy = synchronized(pending) { val x = ArrayList(pending); pending.clear(); x }
                for (p in copy) say(p[0], p[1], p[2], false)
            } else {
                val copy = synchronized(pending) { val x = ArrayList(pending); pending.clear(); x }
                for (p in copy) onDone?.invoke(p[2])
            }
        }
    }

    private fun clean(t: String): String {
        var s = t.replace(Regex("<[^>]+>"), " ")
        s = s.replace(Regex("[*#_`~>|\\[\\]]"), " ")
        s = s.replace(Regex("https?://\\S+"), " ссылка ")
        s = s.replace(Regex("[\\p{So}\\p{Cs}\\u200d\\ufe0f]"), " ")
        s = s.replace(Regex("\\s+"), " ").trim()
        return if (s.length > 3500) s.substring(0, 3500) else s
    }

    fun say(text: String, lang: String = "ru-RU", id: String = "u" + System.nanoTime(), flush: Boolean = true) {
        val t = clean(text)
        if (t.isBlank()) { onDone?.invoke(id); return }
        // защита от двойной озвучки одной и той же фразы подряд
        val now = System.currentTimeMillis()
        if (t == lastText && now - lastAt < 2500) { onDone?.invoke(id); return }
        lastText = t; lastAt = now
        val e = tts
        if (e == null || !ready) {
            synchronized(pending) { pending.add(arrayOf(t, lang, id)) }
            return
        }
        try {
            val loc = Locale.forLanguageTag(lang.ifBlank { "ru-RU" })
            val r = e.setLanguage(loc)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) e.setLanguage(Locale.getDefault())
            e.speak(t, if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, Bundle(), id)
        } catch (ex: Exception) { onDone?.invoke(id) }
    }

    fun stop() { try { tts?.stop() } catch (e: Exception) {} }

    fun speaking(): Boolean = try { tts?.isSpeaking == true } catch (e: Exception) { false }
}
