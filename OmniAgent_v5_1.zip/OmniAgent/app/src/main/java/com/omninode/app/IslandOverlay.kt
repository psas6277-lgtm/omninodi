package com.omninode.app

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.widget.FrameLayout

/** Dynamic Island поверх приложений: чёрная капсула из веб-части (index.html#island), окно подгоняется под размер капсулы. */
class IslandOverlay(private val ctx: Context, private val wm: WindowManager) {
    private val h = Handler(Looper.getMainLooper())
    private var frame: FrameLayout? = null
    private var web: WebView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var curW = 0
    private var curH = 0
    private var wantW = 0
    private var wantH = 0
    private var focusable = false
    private var paused = false
    var hiddenByApp = false
        set(v) { field = v; apply() }
    private var shrink: Runnable? = null

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
    private fun statusH(): Int {
        val id = ctx.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else dp(24)
    }

    fun attach() {
        if (frame != null) return
        val c = ContextThemeWrapper(ctx, android.R.style.Theme_DeviceDefault)
        val f = object : FrameLayout(c) {
            override fun dispatchTouchEvent(e: MotionEvent): Boolean {
                if (e.action == MotionEvent.ACTION_OUTSIDE) {
                    web?.evaluateJavascript("window.OmniIsland&&OmniIsland.close&&OmniIsland.close()", null)
                    return true
                }
                return super.dispatchTouchEvent(e)
            }
        }
        val w = WebView(c)
        WebSetup.setup(w, ctx)
        w.setBackgroundColor(Color.TRANSPARENT)
        w.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        w.isVerticalScrollBarEnabled = false
        w.isHorizontalScrollBarEnabled = false
        w.overScrollMode = View.OVER_SCROLL_NEVER
        OverlayService.webs.add(w)
        f.addView(w, FrameLayout.LayoutParams(-1, -1))
        val p = WindowManager.LayoutParams(1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, baseFlags() or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.y = statusH()
        if (Build.VERSION.SDK_INT >= 28) p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        f.visibility = View.INVISIBLE
        try { wm.addView(f, p) } catch (e: Exception) { OverlayService.webs.remove(w); w.destroy(); return }
        frame = f; web = w; lp = p
        w.loadUrl("https://appassets.androidplatform.net/assets/index.html#island")
    }

    private fun baseFlags(): Int {
        var fl = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        if (!focusable) fl = fl or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        return fl
    }

    /** Размер из веб-части: "w,h,bubble,expanded,top" в dp. */
    fun resize(msg: String) {
        val a = msg.split(",").map { it.trim().toIntOrNull() ?: 0 }
        val w = a.getOrElse(0) { 0 }; val hh = a.getOrElse(1) { 0 }
        val bk = a.getOrElse(2) { 0 }; val top = a.getOrElse(4) { 0 }
        if (w <= 0 || hh <= 0) { wantW = 0; wantH = 0; apply(); return }
        val dm = ctx.resources.displayMetrics
        val pad = dp(14)
        var nw = dp(w) + pad * 2 + (if (bk == 1) dp(112) else 0)
        var nh = dp(top) + dp(hh) + pad * 2
        nw = nw.coerceAtMost(dm.widthPixels)
        nh = nh.coerceAtMost(dm.heightPixels - statusH())
        wantW = nw; wantH = nh
        apply()
    }

    private fun layout(w: Int, hh: Int) {
        val p = lp ?: return
        val f = frame ?: return
        p.width = w; p.height = hh
        try { wm.updateViewLayout(f, p) } catch (e: Exception) {}
        curW = w; curH = hh
    }

    private fun apply() {
        val f = frame ?: return
        val p = lp ?: return
        shrink?.let { h.removeCallbacks(it) }
        if (wantW <= 0 || wantH <= 0 || hiddenByApp) {
            f.visibility = View.INVISIBLE
            p.flags = baseFlags() or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            layout(1, 1)
            if (wantW <= 0 && !paused) { try { web?.onPause() } catch (e: Exception) {}; paused = true }
            return
        }
        if (paused) { try { web?.onResume() } catch (e: Exception) {}; paused = false }
        p.flags = baseFlags()
        f.visibility = View.VISIBLE
        if (wantW >= curW || wantH >= curH) {
            layout(maxOf(wantW, curW), maxOf(wantH, curH))
            if (wantW < curW || wantH < curH) schedule()
        } else schedule()
    }

    private fun schedule() {
        val r = Runnable { if (wantW > 0 && !hiddenByApp) layout(wantW, wantH) }
        shrink = r
        h.postDelayed(r, 700)
    }

    fun wake() {
        if (paused) { try { web?.onResume() } catch (e: Exception) {}; paused = false }
    }

    fun setFocusable(on: Boolean) {
        focusable = on
        val p = lp ?: return
        p.flags = baseFlags()
        if (wantW <= 0 || hiddenByApp) p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        frame?.let { try { wm.updateViewLayout(it, p) } catch (e: Exception) {} }
        if (on) web?.requestFocus()
    }

    fun reload() { wake(); web?.reload() }

    fun detach() {
        shrink?.let { h.removeCallbacks(it) }
        frame?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        web?.let { OverlayService.webs.remove(it); try { it.destroy() } catch (e: Exception) {} }
        frame = null; web = null; lp = null
    }
}
