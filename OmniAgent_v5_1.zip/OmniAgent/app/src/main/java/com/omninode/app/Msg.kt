package com.omninode.app

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject

/** Включение/выключение ядра и острова поверх приложений. */
object Modes {
    fun ensureService(c: Context): Boolean {
        if (!Settings.canDrawOverlays(c)) return false
        return try { c.startForegroundService(Intent(c, OverlayService::class.java)); true } catch (e: Exception) { false }
    }

    /** Применяет сохранённые переключатели. false — не хватает разрешения «Поверх других приложений». */
    fun apply(c: Context): Boolean {
        val need = Prefs.b(c, "core_on") || Prefs.b(c, "island_on") || Prefs.b(c, "bg_on")
        if (need) return ensureService(c)
        OverlayService.inst?.applyModes()
        return true
    }
}

/** Отложенные действия агента («через 10 минут напиши…»). Переживают перезапуск службы. */
object Jobs {
    private val h = Handler(Looper.getMainLooper())
    private val armed = HashSet<Long>()

    private fun load(c: Context): JSONArray = try { JSONArray(Prefs.sp(c).getString("jobs", "[]")) } catch (e: Exception) { JSONArray() }
    private fun save(c: Context, a: JSONArray) { Prefs.sp(c).edit().putString("jobs", a.toString()).apply() }

    fun pending(c: Context): Int = load(c).length()

    fun add(c: Context, j: JSONObject) {
        val a = load(c); a.put(j); save(c, a)
        arm(c, j)
        Modes.ensureService(c)
    }

    fun restore(c: Context) {
        val a = load(c)
        for (i in 0 until a.length()) { val j = a.optJSONObject(i); if (j != null) arm(c, j) }
    }

    private fun arm(c: Context, j: JSONObject) {
        val id = j.optLong("id")
        if (!armed.add(id)) return
        val delay = (j.optLong("at") - System.currentTimeMillis()).coerceAtLeast(0L)
        h.postDelayed({ fire(c, j) }, delay)
    }

    private fun fire(c: Context, j: JSONObject) {
        val id = j.optLong("id")
        armed.remove(id)
        val a = load(c); val keep = JSONArray()
        for (i in 0 until a.length()) { val x = a.optJSONObject(i); if (x != null && x.optLong("id") != id) keep.put(x) }
        save(c, keep)
        val act = j.optJSONObject("a")
        if (act != null) Thread { Steps.runAction(c, act) }.start()
        OverlayService.inst?.applyModes()
    }
}

/** Диспетчер строковых команд JS → Android (протокол «OmniNative.call/postMessage»). */
object Msg {
    private fun bg(f: () -> Unit) { Thread { try { f() } catch (e: Exception) {} }.start() }

    fun handle(c0: Context, m: String): Boolean {
        val c = c0.applicationContext
        try {
            when {
                m == "start" -> { Prefs.set(c, "island_on", true); return Modes.apply(c) }
                m == "stop" -> { Prefs.set(c, "island_on", false); return Modes.apply(c) }
                m == "startCore" -> { Prefs.set(c, "core_on", true); return Modes.apply(c) }
                m == "stopCore" -> { Prefs.set(c, "core_on", false); return Modes.apply(c) }
                m == "startBg" -> { Prefs.set(c, "bg_on", true); Modes.apply(c); return true }
                m == "stopBg" -> { Prefs.set(c, "bg_on", false); Modes.apply(c); return true }
                m == "startHome" || m == "stopHome" -> return true
                m == "hideInGames" -> { Prefs.set(c, "hide_games", true); OverlayService.inst?.applyModes(); return true }
                m == "showInGames" -> { Prefs.set(c, "hide_games", false); OverlayService.inst?.applyModes(); return true }

                m == "poweroff" -> return Sys.powerOff(c)
                m == "screenOff" || m == "lock" -> return AgentService.inst != null && Sys.nav(c, "lock").isNotBlank()
                m == "screenshot" -> return AgentService.inst != null && Sys.nav(c, "shot").isNotBlank()
                m == "mute" -> return Sys.mute(c)
                m == "camera" -> {
                    val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i); return true
                }
                m == "notifDigest" -> return true

                m.startsWith("vol:") -> {
                    val p = m.substring(4).split(":")
                    return if (p.size >= 2) Sys.setVolume(c, p[0], p[1].toIntOrNull() ?: 50) else Sys.setVolume(c, "m", p[0].toIntOrNull() ?: 50)
                }
                m.startsWith("bright:") -> { val v = m.substring(7).toIntOrNull() ?: 100; return Sys.brightness(c, v) }
                m.startsWith("media:") -> return Sys.media(c, m.substring(6))
                m.startsWith("call_") -> return callAction(c, m.substring(5))

                m.startsWith("agent:step:") -> {
                    val j = JSONObject(m.substring(11)); bg { Steps.runStep(c, j) }; return true
                }
                m.startsWith("agent:chain:") -> { Steps.runChain(c, JSONArray(m.substring(12))); return true }
                m.startsWith("agent:schedule:") -> { Jobs.add(c, JSONObject(m.substring(15))); return true }
                m == "agent:screen" -> {
                    bg {
                        val t = AgentService.inst?.screenText()
                        val arg = if (t == null) "null" else JSONObject.quote(t)
                        OverlayService.emit("window.OmniAgent&&OmniAgent.screen(" + arg + ")")
                    }
                    return true
                }

                m.startsWith("win:") -> { OverlayService.inst?.islandWin(m.substring(4)); return true }
                m == "isl:focus:1" -> { OverlayService.inst?.islandFocus(true); return true }
                m == "isl:focus:0" -> { OverlayService.inst?.islandFocus(false); return true }
                m == "isl:cfg" -> { OverlayService.inst?.islandReload(); return true }
                m.startsWith("reply:") -> { val r = m.substring(6); val k = r.indexOf('|'); if (k > 0) OverlayService.inst?.sendReply(r.substring(0, k), r.substring(k + 1)); return true }
                m.startsWith("read:") -> return true
                m == "ring:on" -> { OverlayService.inst?.ringOn(); return true }
                m == "ring:off" -> { OverlayService.inst?.ringOff(true); return true }
                m.startsWith("timer:") -> { val p = m.substring(6).split(":", limit = 2); val s = p[0].toIntOrNull() ?: 0; if (s > 0) OverlayService.inst?.syncTimer(s, p.getOrElse(1) { "Таймер" }); return true }
                m == "agent:stop" -> { OverlayService.inst?.stopAgents(); return true }
                m == "nav:open" -> { OverlayService.inst?.navOpen(); return true }
                m == "core:collapse" -> { OverlayService.inst?.coreCollapse(); return true }
                m == "rec:stop" || m == "ride:call" || m == "ride:msg" || m == "update:start" -> return true
                else -> return false
            }
        } catch (e: Exception) {
            return false
        }
    }

    private fun callAction(c: Context, a: String): Boolean {
        return try {
            val tm = c.getSystemService(Context.TELECOM_SERVICE) as android.telecom.TelecomManager
            val am = Sys.audio(c)
            when (a) {
                "answer" -> { tm.acceptRingingCall(); true }
                "end" -> { if (android.os.Build.VERSION.SDK_INT >= 28) tm.endCall() else false }
                "mute" -> { am.isMicrophoneMute = true; true }
                "unmute" -> { am.isMicrophoneMute = false; true }
                "speaker" -> { am.isSpeakerphoneOn = true; true }
                "earpiece" -> { am.isSpeakerphoneOn = false; true }
                else -> false
            }
        } catch (e: Exception) { false }
    }
}

/** Объект, доступный в JS как window.OmniNative (call / postMessage). */
class OmniNativeBridge(private val c: Context) {
    @android.webkit.JavascriptInterface fun call(m: String): Boolean = Msg.handle(c, m)
    @android.webkit.JavascriptInterface fun postMessage(m: String): Boolean = Msg.handle(c, m)
}
